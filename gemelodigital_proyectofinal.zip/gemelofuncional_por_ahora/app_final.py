from flask import Flask, request, jsonify
from flask_cors import CORS
import csv
import os
import math
import time
from datetime import datetime

app = Flask(__name__)
CORS(app)

CSV_FILE = "historico_gemelo.csv"

# Diccionario en memoria para asociar cada UID de tarjeta RFID con el nombre de quien abrió
rfid_usuarios = {
    "Standby": "Sin apertura registrada",
    "RFID-MED-01": "Dr. Julián Vásquez"
}

# Marca de tiempo exacta en que la puerta pasó de Cerrada a Abierta
door_opened_timestamp = None

# 1. Estado principal del Gemelo Digital
estado_gemelo = {
    "currentTemp": 20.5,
    "targetTemp": 20.5,
    "humidity": 56.0,
    "doorOpen": False,
    "doorClosed": True,
    "doorOpenSeconds": 0,     # Segundos reales que lleva abierta la puerta
    "doorLongOpen": False,    # True ESTRICTAMENTE cuando lleva >= 30 segundos abierta
    "mode": "auto",           # "auto" (bloqueado en 20.5°C) o "manual" (17.0°C a 22.0°C)
    "coolingActive": True,
    "scenario": "nominal",
    # --- DATOS DE RFID Y QUIÉN ABRIÓ LA CAJA ---
    "lastUid": "Standby",
    "lastUser": "Sin apertura registrada",
    "rfidDirectory": rfid_usuarios,
    "lastEventType": "NORMAL",
    # --- DATOS DE LA CÁMARA IA: MATRIZ DE 3 POSICIONES [1, 1, 1] + TIPO Y VENCIMIENTO ---
    "medMatrix": [1, 1, 1],   # 1 = Producto presente, 0 = Vacío
    "medCount": 3,            # Total detectado (0 a 3)
    "expectedCount": 3,       # Stock completo = 3 productos
    "aiConfidence": 98.4,
    "lastAiUpdate": "Sin lectura aún",
    "medDetails": [
        {"slot": 1, "name": "Adrenalina 1mg/mL", "expiry": "2027-06-15"},
        {"slot": 2, "name": "Atropina 1mg/mL", "expiry": "2026-12-10"},
        {"slot": 3, "name": "Amiodarona 150mg", "expiry": "2027-03-20"}
    ],
    # --- MÉTRICAS DEL PDF (ISO 23247-2) ---
    "mktTemp": 20.5,
    "compliancePct": 100.0,
    "openingEvents": 0,
    "excursionAlert": "Estable (Sin excursión prevista)"
}

historico_lecturas = []
total_muestras = 0
muestras_en_rango = 0

if not os.path.exists(CSV_FILE):
    with open(CSV_FILE, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            "Fecha_Hora", "Origen", "Temp_Actual_C", "Temp_Objetivo_C",
            "Humedad_RH", "Puerta_Abierta", "RFID_UID", "Usuario_Apertura",
            "Modo", "Enfriando", "Matriz_IA", "Medicamentos_IA",
            "Detalle_Medicamentos", "MKT_C", "Cumplimiento_Pct", "Alerta"
        ])

def actualizar_cronometro_puerta(esta_abierta):
    """Mide estrictamente los segundos reales desde que se abrió la puerta (sin forzar antes de 30s)."""
    global door_opened_timestamp
    ahora_ts = time.time()

    if esta_abierta:
        if door_opened_timestamp is None:
            door_opened_timestamp = ahora_ts
        segundos = int(ahora_ts - door_opened_timestamp)
        estado_gemelo["doorOpenSeconds"] = segundos
        estado_gemelo["doorLongOpen"] = (segundos >= 30)
    else:
        door_opened_timestamp = None
        estado_gemelo["doorOpenSeconds"] = 0
        estado_gemelo["doorLongOpen"] = False

def actualizar_matriz_ia(nueva_lista):
    """Actualiza la matriz de 3 posiciones [1, 1, 1] solo cuando la puerta está abierta."""
    if not estado_gemelo["doorOpen"]:
        estado_gemelo["lastAiUpdate"] = "Puerta cerrada"
        return

    if isinstance(nueva_lista, list) and len(nueva_lista) >= 3:
        matriz = [1 if int(x) > 0 else 0 for x in nueva_lista[:3]]
        estado_gemelo["medMatrix"] = matriz
        estado_gemelo["medCount"] = sum(matriz)
        estado_gemelo["lastAiUpdate"] = datetime.now().strftime("%H:%M:%S")

def calcular_metricas_pdf(temp_nueva, puerta_cambio):
    global total_muestras, muestras_en_rango

    total_muestras += 1
    if 17.0 <= temp_nueva <= 22.0:
        muestras_en_rango += 1
    estado_gemelo["compliancePct"] = round((muestras_en_rango / total_muestras) * 100, 1)

    if puerta_cambio:
        estado_gemelo["openingEvents"] += 1

    temps_recientes = [r["currentTemp"] for r in historico_lecturas[-30:]] + [temp_nueva]
    R = 0.0083144
    dH = 83.144
    suma_exp = sum(math.exp(-dH / (R * (t + 273.15))) for t in temps_recientes)
    mkt_kelvin = (-dH / R) / math.log(suma_exp / len(temps_recientes))
    estado_gemelo["mktTemp"] = round(mkt_kelvin - 273.15, 2)

    # 1. Alerta de puerta abierta SOLO si ya cumplió >= 30 segundos abierta
    if estado_gemelo["doorOpen"] and estado_gemelo["doorLongOpen"]:
        estado_gemelo["excursionAlert"] = f"¡ALERTA CRÍTICA! Puerta abierta por más de 30s ({estado_gemelo['doorOpenSeconds']}s). ¡Ciérrala!"
        return

    # 2. Durante los primeros 29 segundos de puerta abierta o con puerta cerrada, evaluar estado térmico normal
    if len(historico_lecturas) >= 3:
        pendiente = (temp_nueva - historico_lecturas[-3]["currentTemp"]) / 3.0
        if temp_nueva > 22.0 or temp_nueva < 17.0:
            estado_gemelo["excursionAlert"] = "¡EXCURSIÓN ACTIVA! Fuera de 17-22 °C"
        elif temp_nueva >= 21.3 and pendiente > 0.04:
            ciclos_restantes = (22.0 - temp_nueva) / pendiente
            minutos_est = max(1, round((ciclos_restantes * 2) / 60, 1))
            estado_gemelo["excursionAlert"] = f"Alerta: Excursión hacia >22°C en ~{minutos_est} min"
        else:
            estado_gemelo["excursionAlert"] = "Estable (Sin excursión prevista)"
    else:
        estado_gemelo["excursionAlert"] = "Estable (Sin excursión prevista)"

def registrar_historico(origen):
    ahora = datetime.now().strftime("%H:%M:%S")
    if estado_gemelo["doorOpen"]:
        matriz_str = f"[{estado_gemelo['medMatrix'][0]}, {estado_gemelo['medMatrix'][1]}, {estado_gemelo['medMatrix'][2]}]"
    else:
        matriz_str = "Puerta cerrada"

    resumen_meds = " | ".join([
        f"P{i+1}:{m['name']}({m['expiry']})" if estado_gemelo['medMatrix'][i] == 1 else f"P{i+1}:Vacío"
        for i, m in enumerate(estado_gemelo["medDetails"])
    ])

    registro = {
        "time": ahora,
        "source": origen,
        "currentTemp": round(estado_gemelo["currentTemp"], 1),
        "targetTemp": round(estado_gemelo["targetTemp"], 1),
        "humidity": round(estado_gemelo["humidity"]),
        "doorOpen": estado_gemelo["doorOpen"],
        "doorOpenSeconds": estado_gemelo["doorOpenSeconds"],
        "doorLongOpen": estado_gemelo["doorLongOpen"],
        "lastUid": estado_gemelo["lastUid"],
        "lastUser": estado_gemelo["lastUser"],
        "mode": estado_gemelo["mode"],
        "coolingActive": estado_gemelo["coolingActive"],
        "medMatrix": list(estado_gemelo["medMatrix"]),
        "medMatrixStr": matriz_str,
        "medCount": estado_gemelo["medCount"],
        "mktTemp": estado_gemelo["mktTemp"],
        "compliancePct": estado_gemelo["compliancePct"],
        "alert": estado_gemelo["excursionAlert"]
    }

    historico_lecturas.append(registro)
    if len(historico_lecturas) > 50:
        historico_lecturas.pop(0)

    with open(CSV_FILE, mode='a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"), origen,
            registro["currentTemp"], registro["targetTemp"], registro["humidity"],
            "Abierta" if registro["doorOpen"] else "Cerrada",
            registro["lastUid"], registro["lastUser"],
            registro["mode"], "Activo" if registro["coolingActive"] else "Reposo",
            matriz_str, registro["medCount"], resumen_meds,
            registro["mktTemp"], registro["compliancePct"], registro["alert"]
        ])

# --- RUTAS HTTP DEL BACKEND ---

@app.route('/api/state', methods=['GET'])
def get_state():
    if estado_gemelo["doorOpen"]:
        actualizar_cronometro_puerta(True)
        calcular_metricas_pdf(estado_gemelo["currentTemp"], False)
    return jsonify({
        "state": estado_gemelo,
        "history": list(reversed(historico_lecturas[-12:]))
    })

@app.route('/api/web_update', methods=['POST'])
def web_update():
    data = request.get_json(silent=True) or {}
    puerta_se_abrio = ("doorOpen" in data and data["doorOpen"] == True and estado_gemelo["doorOpen"] == False)

    for key in ["currentTemp", "humidity", "doorOpen", "mode", "coolingActive", "scenario", "expectedCount", "lastUid", "lastUser"]:
        if key in data:
            estado_gemelo[key] = data[key]

    # En modo Automático NO permite cambiar targetTemp (siempre 20.5°C); solo en modo Manual
    if estado_gemelo["mode"] == "auto":
        estado_gemelo["targetTemp"] = 20.5
    else:
        if "targetTemp" in data:
            estado_gemelo["targetTemp"] = max(17.0, min(22.0, float(data["targetTemp"])))

    estado_gemelo["doorClosed"] = not estado_gemelo["doorOpen"]
    actualizar_cronometro_puerta(estado_gemelo["doorOpen"])

    if "assignRfidUser" in data and isinstance(data["assignRfidUser"], dict):
        uid_key = str(data["assignRfidUser"].get("uid", estado_gemelo["lastUid"])).strip()
        user_name = str(data["assignRfidUser"].get("user", "")).strip()
        if uid_key and user_name:
            rfid_usuarios[uid_key] = user_name
            estado_gemelo["lastUid"] = uid_key
            estado_gemelo["lastUser"] = user_name
            estado_gemelo["rfidDirectory"] = rfid_usuarios

    if "medDetails" in data and isinstance(data["medDetails"], list) and len(data["medDetails"]) == 3:
        estado_gemelo["medDetails"] = data["medDetails"]

    origen_web = data.get("source", "")
    if "medMatrix" in data and isinstance(data["medMatrix"], list) and ("Matriz" in origen_web or "Escenario" in origen_web):
        matriz = [1 if int(x) > 0 else 0 for x in data["medMatrix"][:3]]
        estado_gemelo["medMatrix"] = matriz
        estado_gemelo["medCount"] = sum(matriz)
        estado_gemelo["lastAiUpdate"] = datetime.now().strftime("%H:%M:%S")

    calcular_metricas_pdf(estado_gemelo["currentTemp"], puerta_se_abrio)
    registrar_historico(data.get("source", "Web / Simulador"))

    return jsonify({"status": "ok", "state": estado_gemelo})

@app.route('/api/inventory', methods=['POST'])
@app.route('/api/camera', methods=['POST'])
@app.route('/api/ai', methods=['POST'])
def ai_inventory_update():
    data = request.get_json(silent=True) or {}

    if not estado_gemelo["doorOpen"]:
        estado_gemelo["lastAiUpdate"] = "Puerta cerrada"
        return jsonify({
            "status": "door_closed",
            "message": "Puerta cerrada",
            "medMatrix": estado_gemelo["medMatrix"],
            "medCount": estado_gemelo["medCount"],
            "lastAiUpdate": "Puerta cerrada"
        })

    if isinstance(data, list):
        actualizar_matriz_ia(data)
    elif isinstance(data, dict):
        for key in ["slots", "positions", "matrix", "matriz", "medMatrix", "products", "productos", "inventory", "items", "data", "array"]:
            if key in data and isinstance(data[key], list):
                actualizar_matriz_ia(data[key])
                break
        else:
            if all(k in data for k in ["p1", "p2", "p3"]):
                actualizar_matriz_ia([data["p1"], data["p2"], data["p3"]])
            elif all(k in data for k in ["pos1", "pos2", "pos3"]):
                actualizar_matriz_ia([data["pos1"], data["pos2"], data["pos3"]])
            elif "medCount" in data or "count" in data or "cantidad" in data:
                c = int(data.get("medCount", data.get("count", data.get("cantidad", 3))))
                actualizar_matriz_ia([1 if i < c else 0 for i in range(3)])

        if "expectedCount" in data:
            estado_gemelo["expectedCount"] = int(data["expectedCount"])
        if "confidence" in data:
            estado_gemelo["aiConfidence"] = float(data["confidence"])

    registrar_historico("Cámara IA")

    return jsonify({
        "status": "ok",
        "medMatrix": estado_gemelo["medMatrix"],
        "medCount": estado_gemelo["medCount"],
        "medDetails": estado_gemelo["medDetails"],
        "lastAiUpdate": estado_gemelo["lastAiUpdate"]
    })

@app.route('/api/esp32', methods=['POST'])
@app.route('/api/door', methods=['POST', 'GET'])
def esp32_sync():
    data = request.get_json(silent=True) or request.args.to_dict() or {}
    puerta_estaba_cerrada = not estado_gemelo["doorOpen"]

    if "currentTemp" in data:
        estado_gemelo["currentTemp"] = float(data["currentTemp"])
    elif "temperature" in data:
        estado_gemelo["currentTemp"] = float(data["temperature"])

    if "humidity" in data:
        estado_gemelo["humidity"] = float(data["humidity"])

    if "doorClosed" in data:
        cerrada = str(data["doorClosed"]).lower() in ["true", "1", "yes"]
        estado_gemelo["doorClosed"] = cerrada
        estado_gemelo["doorOpen"] = not cerrada
    elif "doorOpen" in data:
        abierta = str(data["doorOpen"]).lower() in ["true", "1", "yes"]
        estado_gemelo["doorOpen"] = abierta
        estado_gemelo["doorClosed"] = not abierta

    if "uid" in data:
        uid_limpio = str(data["uid"]).strip()
        if uid_limpio != "" and uid_limpio.upper() not in ["NONE", "NULL", "NAN"]:
            estado_gemelo["lastUid"] = uid_limpio
            if uid_limpio in rfid_usuarios:
                estado_gemelo["lastUser"] = rfid_usuarios[uid_limpio]
            else:
                estado_gemelo["lastUser"] = "Sin asignar (Escribe nombre abajo)"

    evento_recibido = str(data.get("event", data.get("eventType", "")))
    if evento_recibido:
        estado_gemelo["lastEventType"] = evento_recibido
        if "WARNING_DOOR_IS_OPEN" in evento_recibido:
            estado_gemelo["doorOpen"] = True
            estado_gemelo["doorClosed"] = False
        elif evento_recibido == "door_closed" or "CLOSED" in evento_recibido.upper():
            estado_gemelo["doorOpen"] = False
            estado_gemelo["doorClosed"] = True

    # El cronómetro de 30 segundos manda siempre: solo activa doorLongOpen cuando lleva >= 30s reales
    actualizar_cronometro_puerta(estado_gemelo["doorOpen"])

    if "matrix" in data and isinstance(data["matrix"], list):
        actualizar_matriz_ia(data["matrix"])
    elif "slots" in data and isinstance(data["slots"], list):
        actualizar_matriz_ia(data["slots"])
    elif "medCount" in data:
        c = int(data["medCount"])
        actualizar_matriz_ia([1 if i < c else 0 for i in range(3)])

    if estado_gemelo["mode"] == "auto":
        estado_gemelo["targetTemp"] = 20.5
        if estado_gemelo["currentTemp"] > estado_gemelo["targetTemp"] + 0.2:
            estado_gemelo["coolingActive"] = True
        elif estado_gemelo["currentTemp"] < estado_gemelo["targetTemp"] - 0.2:
            estado_gemelo["coolingActive"] = False

    puerta_se_abrio = (puerta_estaba_cerrada and estado_gemelo["doorOpen"])
    calcular_metricas_pdf(estado_gemelo["currentTemp"], puerta_se_abrio)
    registrar_historico("ESP32 HTTP")

    return jsonify({
        "coolingActive": estado_gemelo["coolingActive"],
        "targetTemp": estado_gemelo["targetTemp"],
        "mode": estado_gemelo["mode"],
        "doorOpenCommand": estado_gemelo["doorOpen"],
        "medMatrix": estado_gemelo["medMatrix"],
        "medCount": estado_gemelo["medCount"]
    })

if __name__ == '__main__':
    print("Backend HTTP del Gemelo Digital corriendo en http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)